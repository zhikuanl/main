package entity;

import util.Loc;

public interface HasLoc {
    Loc getLoc();
}
