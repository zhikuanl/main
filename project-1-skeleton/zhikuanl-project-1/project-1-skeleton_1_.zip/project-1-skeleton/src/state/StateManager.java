package state;

public interface StateManager {
    void transfer(String key);
}
